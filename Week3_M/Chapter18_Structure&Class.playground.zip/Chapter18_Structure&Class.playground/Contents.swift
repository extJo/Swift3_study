//
//  main.swift
//  Chapter18_Struct&Class
//
//  Created by JoYoungHo on 2017. 1. 16..
//  Copyright © 2017년 JoYoungHo. All rights reserved.
//

import Foundation

// Swift는 클래스보다 값 형식인 구조체를 선호
// 동적 바인딩과 Dynamic Dispatch 등 클래스를 사용할 때 발생하는 부하를 피하기 위해
// 상속이 필요하거나 반드시 참조 형식으로 구현해야 하는 경우를 제외하고는 구조체로 구현

// Swift의 구조체
/*
 struct 구조체 이름
 {
 var(let) 멤버 이름: 멤버 자료형
 var(let) 멤버 이름: 멤버 자료형
 var(let) 멤버 이름: 멤버 자료형
 ...
 }
*/

// 구조체 멤버의 값을 읽거나 새로운 값을 할당하기 전에 반드시! 유효한 값으로 초기화되어야 한다.
// 따라서, 선언과 동시에 초기화하거나 멤버를 선언할 때 기본 값을 지정
// 구조체를 초기화할 때에는 생성자를 사용, 따로 만들지 않으면 기본 생성자를 제공

struct Person
{
    var name: String
    var age: Int
}

var someone = Person(name: "John doe", age: 0) // 변수 생성과 동시에 초기화
print(someone.name)
print(someone.age)

someone.name = "James"
someone.age = 34
print(someone.name)
print(someone.age)

// --------------------------------------------------------------------------------- //

// Swift의 클래스
// Java, C#과 동일한 방식으로 한 파일내에 구현
// 동일한 모듈에 있는 클래스를 자도으로 인식 --> 따라서 같은 모듈 내에서는 임포트할 필요 없음

// New File -> Cocoa Class로 파일 생성

/*
 class 클래스 이름: 상위 클래스 이름 // 상위 클래스 이름은 생략 가능
 {
 속성 목록
 메소드 목록
 }
 */

class PersonClass
{
    var name = ""
    var age = 0
    
    func sayHello() {
        print("Hello, World! I'm \(name)")
    }
}

let p = PersonClass() // 초기화 문법

// --------------------------------------------------------------------------------- //

// 객체의 비교
// == 연산자 -> 값을 비교 --> 재정의 통해 상세한 동일성 비교 가능
// === 연산자 -> 메모리 주소를 비교

// --------------------------------------------------------------------------------- //

// 값 형식: 값이 전달될 때 새로운 복사본이 생성 (원시 자료형, 열거형, 튜플, 구조체)
// 참조 형식: Call by reference, 클래스


let startPoint = CGPoint(x: 0.0, y: 0.0) // 구조체
var endPoint = startPoint // 값 만 복사 // Copy by value

endPoint.x = 100
endPoint.y = 200

print("start point: {\(startPoint.x), \(startPoint.y)}") // start point: {0.0, 0.0}
print("end point: {\(endPoint.x), \(endPoint.y)}") // end point: {100.0, 200.0}

// Swift는 Copy-on-write 최적화를 수행하기 때문에, 실제 값이 변경될 때 복사본을 만들어 할당하고 값을 갱신한다.

// --------------------------------------------------------------------------------- //

class MyPoint
{
    var x = 0.0
    var y = 0.0
}

let startPoint2 = MyPoint()
let endPoint2 = startPoint2 // 참조 형식을 복사

endPoint2.x = 100
endPoint2.y = 200

print("start point: {\(startPoint2.x), \(startPoint2.y)}") // start point: {100.0, 200.0}
print("end point: {\(endPoint2.x), \(endPoint2.y)}") // end point: {100.0, 200.0}

// --------------------------------------------------------------------------------- //

// 클래스 객체
// 프로그램이 시작되면, 클래스를 대표하는 객체가 하나 생성되고, 이를 클래스 객체라고 한다.
// 인스턴스와 달리, 오직 하나만 생성되며, 클래스의 멤버쉽을 확인하거나 특정 인스턴스에 종속되지 않은 메소드를 호출할 때 사용된다







