//
//  main.swift
//  Chapter17_Enumeration
//
//  Created by JoYoungHo on 2017. 1. 16..
//  Copyright © 2017년 JoYoungHo. All rights reserved.
//

import Foundation

// Swift 의 열거형
// Objective-C의 단점을 극복하고, 클래스나 구조체가 가지고 있는 다양한 기능들을 차용
// 특히, 계산된 속성, 인스턴스 메소드, 생성자를 가질 수 있고, 프로토콜을 채용할 수 있다.
// First-class Citizen으로 일반 자료형과 동일한 지위를 획득

// enum 키워드
// case는 camelBack 방식으로 작성

/*
 enum 열거형 이름
 {
 case 멤버
 case 멤버
 ...
 }
 */

/*
 enum 열거형 이름
 {
 case 멤버, 멤버, 멤버 ...
 }
 */

// Swift에서는 멤버들의 원시 값을 지정하지 않는 이상 원시 값을 가지지 않는다.
// Swift에서 열거형은 Int Double과 같이 독립적인 자료형이다.
// 따라서, 사용하고자 할때에도, enum 키워드는 불필요 하다.

/*
 열거형 이름.열거형 멤버 이름
 */

/*
 enum WeekDay
 {
 case sunday
 case monday
 case tuesday
 case wednesday
 case thursday
 case friday
 case saturday
 }
 
 let week = WeekDay.sunday
 
 let week2: WeekDay = .sunday // 형식 추론 사용
 */

// 오늘의 요일을 출력하는 코드
enum Weekday: Int // 원시값을 지정해줌
{
    case sunday = 1, monday, tuesday, wednesday, thursday, friday, saturday
}

let calendar = NSCalendar.current
let week = Weekday(rawValue: calendar.component(Calendar.Component.weekday, from: Date()))!

switch week
{
case .sunday:
    print("Today is Sunday")
case .monday:
    print("Today is Monday")
case .tuesday:
    print("Today is Tuesday")
case .wednesday:
    print("Today is Wednesday")
case .thursday:
    print("Today is Thursday")
case .friday:
    print("Today is Friday")
case .saturday:
    print("Today is Saturday")
}

// ------------------------------------------------------------------------ //

// Swift 에서 원시값의 다양한 자료형을 가질 수 있다
// 숫자형의 경우 0 1 2 3 ... 을 가지게 된다
// String으로 지정할 경우, 따로 지정하지 않으면 멤버 이름과 동일한 String 값을 가지게 된다.
// 또한, 열거형 내부 원시값은 유일하다.
// 멤버의 원시 값을 알기 위해서는 rawValue 속성을 이용해야 한다.

enum WeekdayName: String
{
    case sunday = "SUN", monday, tuesday, wednesday, thursday, friday, saturday
}

print(WeekdayName.sunday) // sunday

print(WeekdayName.sunday.rawValue) // SUN

print(WeekdayName.monday) // monday

print(WeekdayName.monday.rawValue) // monday


// ------------------------------------------------------------------------ //


// 열거형은 또한, 연관 값을 통해 자료형 제한없는 부가적인 정보를 저장 할 수 있다.
// 같은 멤버라도 다양한 부가정보를 저장 할 수 있다.
// 다른 언어의 Discriminated Unions, Tagged Unions, Variants 등과 유사한 요소로 볼 수 있다.
// 주의. 연관 값을 가지게 되면, 원시 값을 가질 수 없다.
// 연관 값은 열거형을 변수나 상수에 할당하는 시점에 초기화한다.


enum DateFormat
{
    case long(Int, Int, Int, String)
    case short(Int, Int)
}

let startDate = DateFormat.long(2016, 5, 1, "Sunday")
var endDate = DateFormat.long(2016, 5, 7, "Saturday")
endDate = .short(8, 31) // 이미 DataFormat의 멤버 변수임을 알기 때문에, 축약해서 작성가능하다.
endDate = .short(9, 2)

switch startDate
{
case .long(let year, let month, let day, let weekday): // 각각 새로운 변수로 할당 가능하다.
    print("\(year)-\(month)-\(day) \(weekday)")
case .short(let month, let day):
    print("\(month)-\(day)")
}

switch startDate
{
case let .long(year, month, day, weekday): // 전부 같은 형태로 할당할 때에는 case 바로 뒤에 써 줄 수 있다.
    print("\(year)-\(month)-\(day) \(weekday)")
case .short(let month, _): // 필요없는 것은 _로 생략가능하다.
    print("\(month)")
}

