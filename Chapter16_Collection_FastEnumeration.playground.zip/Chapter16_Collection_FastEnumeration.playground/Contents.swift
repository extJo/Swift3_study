//
//  main.swift
//  Chapter18_Collection_FastEnumetration
//
//  Created by JoYoungHo on 2017. 1. 15..
//  Copyright © 2017년 JoYoungHo. All rights reserved.
//

import Foundation

// 열거: 모든 데이터를 순회하면서 필요한 작업을 수행하는 것
// NSEnumerator: 나름 좋은 성능을 보이지만, 역순으로 열거할 떄를 제외하고는 사용하지 않는다.
// 빠른 열거: 멀티쓰레드 환경에서 다수의 열거를 동시 수행 가능, 하지만 열거를 수행하는 동안 수정, 추가는 금지 --> 런타임에러 발생

// 6.1 배열 셋 열거
// for "요소 상수"  in  "배열 또는 셋"
// {
//
// }

// 배열을 열거하면 기본적으로 오름차순으로 정렬되어 전달
// 셋은 순서가 랜덤


let array = ["Apple", "Orange", "Melon"]

// 오름차순 열거
for value in array
{
    if let index = array.index(of: value)
    {
        print("\(index) - \(value)")
    }
}
// 0 - Apple
// 1 - Orange
// 2 - Melon

let set = Set(array)
for value in set
{
    print(value)
}
// Apple
// Orange
// Melon

// --------------------------------------------------------------- //

// 내림차순 열거
for value in array.reversed()
{
    if let index = array.index(of: value)
    {
        print("\(index) - \(value)")
    }
}
// 2 - Melon
// 0 - Apple
// 1 - Orange

// --------------------------------------------------------------- //

let alphabet = ["A", "B", "C"]

// enumerated() --> 순회 각 단계마다 인덱스와 값으로 된 튜플을 리턴
for t in alphabet.enumerated()
{
    print("#\(t.0) - \(t.1)")
}

for (index, char) in alphabet.enumerated()
{
    print("#\(index) - \(char)")
}
// #0 - A
// #1 - B
// #2 - C

// --------------------------------------------------------------- //

// NSArray와 NSSet은 Concurrent와 Reverse 옵션이 있는데, Concurrent 옵션을 지정하면 CPU 자원을 활용하여 동시에 여러 개의 요소를 열거한다.

// --------------------------------------------------------------- //

// Dictionary의 빠른 열거법
let dict = ["A": "Apple", "B": "Banana", "C": "City"]
for (key, value) in dict
{
    print("\(key): \(value)")
}

// --------------------------------------------------------------- //

let words = ["A":"Apple", "B":"Banana", "C":"City"]

// Dictionary의 key만
for key in words.keys
{
    print(key)
}
// C
// B
// A

// Dictionary의 value만
for val in words.values
{
    print(val)
}
// City
// Banana
// Apple

// --------------------------------------------------------------- //

// 필요없는 값을 _로 생략하는 방법
for (key, _) in dict
{
    print(key)
}
// C
// B
// A

for (_, value) in dict
{
    print(value)
}
// City
// Banana
// Apple

// --------------------------------------------------------------- //

// NSDictionary 또한 Concurrent와 Reverse 옵션을 가지고 있고, Reverse 옵션은 거의 사용되지 않으며, Concurrent 옵션을 사용하면 열거 성능에 도움이 된다.

// --------------------------------------------------------------- //

// 열거중인 Collection 을 바로 수정하면 매우 위험하므로, 따로 삭제할 것을 저장해두었다가 수정할 Collection 을 기준으로 열거하여 기존 Collection 을 수정한다
var array2 = ["Apple", "Orange", "Melon", "Apple", "Orange", "Melon"]
var deleteSet = Set<String>()

for value in array2
{
    if value == "Melon"
    {
        deleteSet.insert(value)
    }
}

for value in deleteSet
{
    var index = array.index(of: value)
    
    while index != nil
    {
        array2.remove(at: index!)
        index = array2.index(of: value)
    }
}
print(array2) // ["Apple", "Orange", "Apple", "Orange"]

// 컬렉션 성능
// 대부분의 method에서 상수 시간을 나타내며, 배열의 경우 중간에 새로운 요소를 삽입한면 메모리의 이동이 순차적으로 일어나므로 선형 시간을 가진다.

