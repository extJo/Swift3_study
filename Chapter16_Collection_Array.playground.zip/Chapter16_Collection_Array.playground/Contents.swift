//
//  main.swift
//  chapter18_collection
//
//  Created by JoYoungHo on 2017. 1. 13..
//  Copyright © 2017년 JoYoungHo. All rights reserved.
//
import Foundation

// 구조체로 구현된 일반화 Collection
// 저장할 자료형의 구분을 명화하게 한다 --> 오류를 사전에 방지
// Objective-C와 다르게 박싱 없이 바로 저장가능

// 복사시 기본적으로 copy-on-write 방식을 따른다. 복사후 값 변경이 없다면, 기존의 원본을 가리키다가
// 값의 변경이 일어나면, 복사본을 만들어 수정값을 갱신한다

// page 344
// Swift Array
// 자료형 유추를 통해 자동으로 자료형 할당

let stringArray1 = ["Apple", "Oragne", "Banana"] // 불가변 배열

// page 345
let stringArray2 = Array(["Apple", "Orange", "Banana"])
let stringNSArray = NSArray(objects: "Apple", "Orange", "Banana") // Foundation

let emptyArray1: NSMutableArray = [] // Foundation
let emptyArray2 = NSMutableArray() // Foundation

// 특히 빈 배열을 선언할 때에는 반드시 자료형 명시
var emptyStringArray1: Array<String> = [] // 가변 배열
var emptyStringArray2 = Array<String>()
var emptyStringArray3: [String] = [] // 단축 문법을 많이 사용
var emptyStringArray4 = [String]()

// var emptyArray = [] // ERROR!!

// page 346
// Array<요소의 자료형>
// [요소의 자료형] // 단축 문법


// 3.1 ===================================================================================== //
print("3.1 =====================================================================================")

// 3.1 배열에 포함된 요소의 수
// page 347
let fruitsArray = ["Apple", "Oreange", "Banana"]
let countOfFruits = fruitsArray.count

if !fruitsArray.isEmpty
{
    print("\(countOfFruits) element(s)")
}
else
{
    print("empty array")
}
// 3 element(s)

// 3.2 ===================================================================================== //
print("3.2 =====================================================================================")

// 3.2 요소에 접근
// page 347
// 요소 접근 방법
let fruitsNSArray: NSArray = ["Apple", "Orange", "Banana"] // Foundation

let first = fruitsNSArray.object(at: 0) // 잘 사용하지 않는 방법들

let last = fruitsNSArray.object(at: fruitsNSArray.count - 1)

print(first) // "Apple"
print(last) // "Banana"

let first2 = fruitsNSArray[0] // 자주 사용되는 방법
let last2 = fruitsNSArray[fruitsNSArray.count - 1]
print(first2) // "Apple"
print(last2) // "Banana"
// 요소 접근 방법 끝

// ----------------------------------------------------------------------------------------- //

// 인덱스 유효 확인
let index = 100
if index > 0 && index < fruitsNSArray.count
{
    print(fruitsNSArray[index])
}
else
{
    print("Out of Bounds") // this will be printed
}
// 인덱스 유효 확인 끝

// ----------------------------------------------------------------------------------------- //

// startIndex, lastIndex, first, last
// 보다 안전하게 배열에 접근
if index >= fruitsArray.startIndex && index < fruitsArray.endIndex
{
    //...
}

if let first = fruitsArray.first
{
    // ...
}

if let last = fruitsArray.last
{
    // ...
}
// startIndex, lastIndex, first, last 끝


// 3.3 ===================================================================================== //
print("3.3 =====================================================================================")


// 3.3 요소검색
// page 349
/* NSArray의 contains 메소드 */
let alphabetNSArray: NSArray = ["A", "B", "C", "D", "E"]

if alphabetNSArray.contains("A")
{
    print("contains A in alphabetNSArray")
}

/* NSArray의 contains 메소드 끝 */

// ----------------------------------------------------------------------------------------- //

/* NSArray의 indexOfObject 메소드 */
// page 351
// 요소가 포함되어 있으면 인덱스 리턴, 아니면 NSNotFound 리턴

let indexOfC = alphabetNSArray.index(of: "C")


if index != NSNotFound
{
    print("index of C: \(index)") // 2
}
/* NSArray의 indexOfObject 메소드 끝 */

// ----------------------------------------------------------------------------------------- //

/* NSArray의 filterdArrayUsingPredicate(_:) 메소드 */ // 검색기능
// page 352
// NSPredicate 객체를 활용하여 새로운 배열을 만듬
// NSMutableArray의 경우 수정된 배열을 리턴
let productNamesNSArray: NSArray = ["iphone", "ipad", "Mac Pro", "iPad Pro", "Macbook Pro"]

let prefixPredicate = NSPredicate(format: "SELF BEGINSWITH %@", "i") // i 로 시작하는 단어 찾기
let filterdNSArray = productNamesNSArray.filtered(using: prefixPredicate)


print(filterdNSArray) // 새로운 배열
// "iPhone" "iPad" "iPad Pro"

let productNamesNSMutableArray = NSMutableArray(array: productNamesNSArray)

let suffixPredicate = NSPredicate(format: "SELF ENDSWITH %@", "o")
productNamesNSMutableArray.filter(using: suffixPredicate)


print(productNamesNSMutableArray) // 수정된 배열
// "Mac Pro", "iPad Pro", "Macbook Pro"
/* NSArray의 filterdArrayUsingPredicate(_:) 메소드 끝 */

// ----------------------------------------------------------------------------------------- //

/* Array의 contains 메소드 */
// page 352
let alphabetArray = ["A", "B", "C", "D", "E"]
if alphabetArray.contains("C")
{
    print("alphabetArray contains C")
}

if alphabetArray.contains(where: { $0 == "A" })
{
    print("alphabetArray contains C using Closure")
}

/* Array의 contains 메소드 끝 */

// ----------------------------------------------------------------------------------------- //

/* Array의 검색 */
// Clousre 를 사용하여 구체화
// page 353
let productNamesArray = ["iPhone", "iPad", "Mac Pro", "iPad Pro", "Macbook Pro"]
let filteredArray = productNamesArray.filter{ (element) -> Bool in
    return element.hasPrefix("i")
}
print(filteredArray)
/* Array의 검색 끝 */

// ----------------------------------------------------------------------------------------- //

/* Array의 indexOf 메소드 */
// page 353
// 요소의 인덱스를 옵셔널로 리턴
if let indexOfCInArray = alphabetArray.index(of: "C")
{
    print("index of C: \(indexOfCInArray)")
}

/* Array의 indexOf 메소드 끝 */

// 3.4 ===================================================================================== //
print("3.4 =====================================================================================")

/* NSArray 의 비교 */
// isEqualtoArray(_:) 메소드
let upperArray = ["A", "B", "C", "D", "E"]
let shuffledArray = ["E", "B", "C", "A", "D"]
let lowerArray = ["a", "b", "c", "d", "e"]
let mixedArray = ["A", "b", "C", "d", "e"]

if alphabetNSArray.isEqual(to: upperArray)
{
    print("alphabetNSArray == upperArray")
}
else
{
    print("alphabetNSArray != upperArray")
}
    
if alphabetNSArray.isEqual(to: shuffledArray)
{
    print("alphabetNSArray == shuffledArray")
}
else
{
    print("alphabetNSArray != shuffeldArray")
}
    
if alphabetNSArray.isEqual(to: lowerArray)
{
    print("alphabetNSArray == lowerArray")
}
else
{
    print("alphabetNSArray != lowerArray")
}
    
if alphabetNSArray.isEqual(to: mixedArray)
{
    print("alphabetNSArray == mixedArray")
}
else
{
    print("alphabetNSARray != mixedArray")
}

// 직접 하는 방법
var equal = true
if alphabetNSArray.count == lowerArray.count
{
    for i in 0..<alphabetNSArray.count
    {
        let lhs = alphabetNSArray[i] as! NSString
        let rhs = lowerArray[i]
        
        if lhs.caseInsensitiveCompare(rhs) != .orderedSame
        {
            equal = false
            break
        }
      
    }
}

if equal
{
    print("alphabetNSArray == lowerArray")
}
else
{
    print("alphabetNSArray != lowerArray")
}
/* NSArray 의 비교 끝 */

// ----------------------------------------------------------------------------------------- //

/* Array 의 비교 */
// == 연산자와 elementsEqual(_:isEquivalent:)
if alphabetArray == lowerArray
{
    print("alphabetArray == lowerArray")
}
else
{
    print("alphabetArray != lowerArray")
}

if alphabetArray.elementsEqual(lowerArray, by: { $0.lowercased() == $1.lowercased() }) // isEquivalent 에서 by로 변경된듯
{
    print("alphabetArray == lowerArray")
}
else
{
    print("alphabetArray != lowerArray")
}



// 3.5 ===================================================================================== //
print("3.5 =====================================================================================")

// 3.5 새로운 요소 추가
// page 358
/* NSMutableArray 의 추가방법 */
// add, insert
let alphabetNSMutableArray = NSMutableArray()

alphabetNSMutableArray.add("B")

print(alphabetNSMutableArray) // "B"

alphabetNSMutableArray.insert("A", at: 0)

print(alphabetNSMutableArray) // "A" "B"
/* NSMutableArray 의 추가방법 끝 */

// ----------------------------------------------------------------------------------------- //

/* Array 의 요소 추가 방법 */
// append, insert
var alphabetVarArray = [String]()
alphabetVarArray.append("B")

alphabetVarArray.insert("A", at: 0)

/* Array 의 요소 추가 방법 끝 */

// 3.6 ===================================================================================== //
print("3.6 =====================================================================================")

// 3.6 요소 교체
// page 359
/* NSMutalbeArray의 요소 교체 방법 */
// replaceObject --> 잘 사용되지 않는 방법
// replaceObjectsInRange --> 범위단위로 교체하기
var alphabetVarNSMutableArray = NSMutableArray(array: ["A", "B", "C"])

alphabetVarNSMutableArray.replaceObject(at: 0, with: "Z")
print(alphabetVarNSMutableArray) // "Z" "B" "C"

alphabetVarNSMutableArray[1] = "D" // 잘 사용되는 방법
print(alphabetVarNSMutableArray) // "Z" "D" "C"

// 범위교체하기
let range = NSRange(location: 0, length: 2)

alphabetVarNSMutableArray.replaceObjects(in: range, withObjectsFrom: ["X", "Y"]) // "Z" "D" "C" --> "X" "Y" "C"

print(alphabetVarNSMutableArray)

// 모든 요소 교체하기
alphabetVarNSMutableArray.setArray(["K", "R"])
print(alphabetVarNSMutableArray)

alphabetVarNSMutableArray.setArray([])
print(alphabetVarNSMutableArray)
/* NSMutalbeArray의 요소 교체 방법 끝 */

// ----------------------------------------------------------------------------------------- //

/* Array 의 교체방법 */
// page 360
// 항상 서브스크립트 문법을 사용하여 교체를 한다
// Range<Int> 구조체로 범위를 지정하여 replaceRange 메소드를 사용하여 범위 교체
alphabetVarArray[0] = "Z" // "A" "B"
print(alphabetVarArray) // "Z" "B"

alphabetVarArray.replaceSubrange(0..<2, with: ["X", "Y"]) // "Z" "B" --> "X" "Y"

print(alphabetVarArray) // "X" "Y"

// startIndex와 endIndex를 활용하는 방법
alphabetVarArray = ["A", "B", "C"]

alphabetVarArray.replaceSubrange(alphabetVarArray.startIndex..<alphabetVarArray.endIndex, with: ["X", "Y"])
print((alphabetVarArray.startIndex..<alphabetVarArray.endIndex.advanced(by: -1)))
print(alphabetVarArray) // "X" "Y" "C"

// 서브스크립트방법을 활용하여 범위 교체 방법
alphabetVarArray = ["A", "B", "C"]

alphabetVarArray[alphabetVarArray.startIndex..<alphabetVarArray.endIndex.advanced(by: -1)] = ["X", "Y"]
print(alphabetVarArray) // "X" "Y" "C"

// 모든 요소를 교체하기
// 다로 메소드를 제공하기 않고 서브스크립트 문법을 활용한다
alphabetVarArray = ["K", "R"]
print(alphabetVarArray)

alphabetVarArray = []
print(alphabetVarArray)
/* Array 의 교체방법 끝 */


// 3.7 ===================================================================================== //
print("3.7 =====================================================================================")

// 3.7 요소 삭제
// page 362

/* NSMutableArray의 요소 삭제 방법 */
alphabetVarNSMutableArray = NSMutableArray(array: ["A", "B", "C", "D", "E"])

alphabetVarNSMutableArray.removeObject(at: 0)
print(alphabetVarNSMutableArray) // "B" "C" "D" "E"

// 범이 단위 지우기
alphabetVarNSMutableArray.removeObjects(in: NSMakeRange(0, 3))
print(alphabetVarNSMutableArray) // "E"

// 마지막 원소 지우기
// removeLastObject <--> removeFirstObject 같은 메소드는 제공하지 않기 때문에 removeObject(0) 을 사용해야 한다.
alphabetVarNSMutableArray = NSMutableArray(array: ["A", "B", "C", "D", "E"])
alphabetVarNSMutableArray.removeLastObject()
print(alphabetVarNSMutableArray) // "A" "B" "C" "D"

alphabetVarNSMutableArray.removeAllObjects()
print(alphabetVarNSMutableArray) // []

// Object 를 찾아서 지우기
// removeObject // 배열에 존재하지 않을 경우 아무것도 하지 않는다.
alphabetVarNSMutableArray = NSMutableArray(array: ["A", "B", "C", "D", "E"])
alphabetVarNSMutableArray.remove("C")
print(alphabetVarNSMutableArray) // "A" "B" "D" "E"

// removeObject 메소드에 범위를 한정하여 삭제 할 수도 있다.
alphabetVarNSMutableArray = NSMutableArray(array: ["A", "B", "C", "D", "E"])
alphabetVarNSMutableArray.remove("C", in: NSMakeRange(0, 2)) // 범위 내 "C" 가 없으므로 삭제가 이루어 지지 않는다.
print(alphabetVarNSMutableArray) // "A" "B" "C" "D" "E"
/* NSMutableArray의 요소 삭제 방법 끝 */

// ----------------------------------------------------------------------------------------- //

/* Array 의 요소 삭제 방법 */
// page 365
// removeAtIndex --> 삭제를 하고 삭제된 요소를 리턴, 삭제된 것이 무엇인지 확인할 때 유용
alphabetVarArray = ["A", "B", "C", "D", "E"]

let removed = alphabetVarArray.remove(at: 0)
print(removed) // A

print(alphabetVarArray) // "B" "C" "D" "E"

// removeFirst, removeLast
// 범위를 지정하지 않고 지울경우, 지워진 요소를 리턴하고, 범위를 지정할 경우 리턴하지 않는다.
alphabetVarArray = ["A", "B", "C", "D", "E"]
let removedFirst = alphabetVarArray.removeFirst()
print(removedFirst) // "A"

alphabetVarArray.removeFirst(2) // 0 ~ 1
print(alphabetVarArray) // "D" "E"

let removedLast = alphabetVarArray.removeLast() // removeLast()는 빈 배열에서 호출할 경우 에러 발생 --> popLast() 메소드로 대체가능 (삭제된 요소를 옵셔널로 리턴)
print(removedLast) // "E"

print(alphabetVarArray) // "D"

// popLast()
alphabetVarArray = ["A", "B", "C", "D", "E"]
if let popedLast = alphabetVarArray.popLast()
{
    print(popedLast) // "E"
}
print(alphabetVarArray) // "A" "B" "C" "D"

// removeAll(keepCapacity:)
// 모든 요소를 지우고, keepCapacitiy(keepingCapacity)가 true면 저장공간 유지 false 면 저장공간도 삭제한다
alphabetVarArray = ["A", "B", "C", "D", "E"]
alphabetVarArray.removeAll(keepingCapacity: true)
print(alphabetVarArray) // []
/* Array 의 요소 삭제 방법 끝 */


// 3.8 ===================================================================================== //
print("3.8 =====================================================================================")

// 3.8 정렬
// page 367

/* NSArray의 정렬 방법 */
// NSArray의 경우 주로 셀렉터, 블록, Sort Descriptor를 활용하여 요소의 순서를 지정한다.
// NSArray: sortedArrayUsingSelector --> 정렬된 새로운 배열을 리턴
// NSMutableArray: sortUsingSelector --> 자체 정렬
// 주의. 셀렉터를 전달할 때 배열에 포함된 요소가 제공하는 메소드의 셀렉터를 전달해야 한다는 것
alphabetNSMutableArray.setArray(["A", "B", "C", "a", "b", "c"])

for i in 0 ..< (alphabetNSMutableArray.count - 1)
{
    let j = Int(arc4random_uniform(UInt32(alphabetNSMutableArray.count - i))) + i
    swap(&alphabetNSMutableArray[i], &alphabetNSMutableArray[j]) // shuffling
}
print(alphabetNSMutableArray)

// 새로운 배열을 리턴
let sortedAlphabetNSMutableArray = alphabetNSMutableArray.sortedArray(using: #selector(NSString.caseInsensitiveCompare(_:)))
print(sortedAlphabetNSMutableArray) // .OrderedSame 이기때문에 A와 a는 같은것으로 판단

// 기존 배열을 수정
alphabetNSMutableArray.sort(using: #selector(NSString.caseInsensitiveCompare(_:)))
print(alphabetNSMutableArray)

// 클로져 활용하기
alphabetNSMutableArray.setArray(["A", "B", "C", "a", "b", "c"])

let sortedAlphabetNSMutableArray2 = alphabetNSMutableArray.sortedArray(comparator: {
    (obj1, obj2) -> ComparisonResult in
    return (obj1 as! String).caseInsensitiveCompare(obj2 as! String)
})
print(sortedAlphabetNSMutableArray2)

alphabetNSMutableArray.sort(comparator: {
    (obj1, obj2) -> ComparisonResult in
    return (obj1 as! String).caseInsensitiveCompare(obj2 as! String)
})
print(alphabetNSMutableArray)

// Sort Descriptor 활용하기
alphabetVarNSMutableArray = NSMutableArray(array: ["A", "B", "C", "D", "E"])

for i in 0 ..< (alphabetVarNSMutableArray.count - 1)
{
    let j = Int(arc4random_uniform(UInt32(alphabetVarNSMutableArray.count - i))) + i
    swap(&alphabetVarNSMutableArray[i], &alphabetVarNSMutableArray[j])
}
print(alphabetVarNSMutableArray)

let asc = NSSortDescriptor(key: "self", ascending: true)
var sortedArrayUsingDescriptor = alphabetVarNSMutableArray.sortedArray(using: [asc])
print(sortedArrayUsingDescriptor)

let desc = NSSortDescriptor(key: "self", ascending: false)
sortedArrayUsingDescriptor = alphabetVarNSMutableArray.sortedArray(using: [desc])
print(sortedArrayUsingDescriptor)
/* NSArray의 정렬 방법 끝 */

// ----------------------------------------------------------------------------------------- //

/* Array의 정렬 방법 */
// page 371
// sort(), sortInPlace()
alphabetVarArray = ["A", "B", "C", "D", "E"]

for i in 0 ..< (alphabetVarArray.count - 1)
{
    let j = Int(arc4random_uniform(UInt32(alphabetVarArray.count - i))) + i
    guard i != j else { continue }
    swap(&alphabetVarArray[i], &alphabetVarArray[j])
}
print(alphabetVarArray)

// 정렬된 새로운 배열 리턴
let sortedAlphabetVarArray = alphabetVarArray.sorted()
print(sortedAlphabetVarArray)

// 자체 정렬
alphabetVarArray.sort()
print(alphabetVarArray)

// 클로져 활용아여 비교 조건 구체화 하기
alphabetVarArray = ["A", "B", "C", "D", "E"]

for i in 0 ..< (alphabetVarArray.count - 1)
{
    let j = Int(arc4random_uniform(UInt32(alphabetVarArray.count - i))) + i
    guard i != j else { continue }
    swap(&alphabetVarArray[i], &alphabetVarArray[j])
}
print(alphabetVarArray)

// 새로운 배열 리턴
let sortedAlphabetVarArray2 = alphabetVarArray.sorted { $0 > $1 }
print(sortedAlphabetVarArray2)

// 기존 배열 정렬
alphabetVarArray.sort { $0 > $1 }
print(alphabetVarArray)

// 역순 정렬할기
// revesre() --> 리턴 값은 ReverseRandomAccessCollection 으로 자료형 직접 지정하면 형변환 없이 정렬된 배열 쉽게 획득가능
print(alphabetArray)

var reversedResult = alphabetArray.reversed()
print(reversedResult)

var reversedResult2: [String] = alphabetArray.reversed()
print(reversedResult2)

reversedResult2 = [String](alphabetArray.reversed())
print(reversedResult2)
/* Array의 정렬 방법 끝 */

// 3.9 ===================================================================================== //
print("3.9 =====================================================================================")

// 3.9 범위 추출
/* NSArray의 범위 추출 */
// subarrayWithRange(_:) --> 특정 범위에 있는 요소들을 새로운 배열로 추출
print(alphabetNSArray)

let subArrayOfAlphabetNSArray = alphabetNSArray.subarray(with: NSMakeRange(1, 3))
print(subArrayOfAlphabetNSArray)

/* NSArray의 범위 추출 끝 */

// ----------------------------------------------------------------------------------------- //

/* Array의 범위 추출 */
// 서브스크립트 문법과 범위 연산자를 조합
let subArrayOfAlphabetArray = alphabetArray[1..<4]
print(subArrayOfAlphabetArray)

// dropFirst() --> 첫 번째 요소를 제외한 나머지 요소를 새로운 배열로 리턴, 정수를 파라미터로 전달하면 그 길이만큼 제외하고 리턴
var resultOfDropFirst = alphabetArray.dropFirst()
print(resultOfDropFirst)

resultOfDropFirst = alphabetArray.dropFirst(3) // 0 ~ 2
print(resultOfDropFirst)

// dropLast() --> 배열 마짐가 부분에 있는 요소를 제외하고 리턴
var rersultOfDropLast = alphabetArray.dropLast()
print(rersultOfDropLast)

rersultOfDropLast = alphabetArray.dropLast(3)
print(rersultOfDropLast)

// prefix() --> 추출할 요소의 수를 파라미터로 전달하면 처음부터 n개 의 요소를 추출, 원래 길이보다 큰 수를 넣으면 전체 배열을 리턴
var resultOfPrefix = alphabetArray.prefix(2)
print(resultOfPrefix)

// prefixUpto() --> 시작 인덱스부터 지정한 인덱스 이전까지 추출 0..<param
var resultOfPrefixUpto = alphabetArray.prefix(upTo: 2)
print(resultOfPrefixUpto)

// prefixThrough() --> prefixUpto 와 유사하지만 지정 인덱스 까지 추출 0...param
var resultOfPrefixThrough = alphabetArray.prefix(through: 2)
print(resultOfPrefixThrough)

// suffix() --> 마지막에 위치한 n개의 요소를 새로운 배열로 리턴
var resultOfSuffix = alphabetArray.suffix(2)
print(resultOfSuffix)

// suffixFrom() --> 전달한 인덱스를 포함하여 이후의 모든 요소를 새로운 배열로 리턴
var resultOfSuffixFrom = alphabetArray.suffix(from: 2)
print(resultOfSuffixFrom)

// split(_:allowEmptySlices:isSeperator:) --> 배열에 포함된 요소 중 분리자로 사용되는 요소를 판단하는 클로져를 통해 배열을 분리후 2차원 배열로 리턴
// 첫 번째 파라미터는 결과 배열의 수 (기본값은 Int.max)
// 빈 배열도 결과 배열에 포함시키고 싶다면 allowEmptySlices를 true로 전달
let alphabetArrayWithSeperator = ["A", "B", "#", "C", "#", "#", "D", "E"]

// 클로져 이용하기
var resultOfSplit = alphabetArrayWithSeperator.split{
    (element) -> Bool in
    return element == "#"
}
print(resultOfSplit)

// sperator 이용하기
resultOfSplit = alphabetArrayWithSeperator.split(separator: "#")
print(resultOfSplit)

// 클로져 및 빈 배열 허용하기
resultOfSplit = alphabetArrayWithSeperator.split(maxSplits: 3, omittingEmptySubsequences: false, whereSeparator: {
    (element) -> Bool in
    return element == "#"
})
print(resultOfSplit)

// sperator 및 빈 배열 허용하기
resultOfSplit = alphabetArrayWithSeperator.split(separator: "#", maxSplits: 3, omittingEmptySubsequences: false)
print(resultOfSplit)

// 클로져 및 빈 배열 허용하기 않기
resultOfSplit = alphabetArrayWithSeperator.split(maxSplits: 3, omittingEmptySubsequences: true, whereSeparator: {
    (element) -> Bool in
    return element == "#"
})
print(resultOfSplit)

// 나누어서 나오는 수보다 작게 배열 할당하기
resultOfSplit = alphabetArrayWithSeperator.split(maxSplits: 2, omittingEmptySubsequences: false, whereSeparator: {
    (element) -> Bool in
    return element == "#"
})
print(resultOfSplit)
/* Array의 범위 추출 끝 */

// 3.10 ===================================================================================== //
print("3.10 =====================================================================================")

// 3.10 배열 변환
/* NSArray의 배열 변환 */
// componentJoinedByString --> 연결자로 연결된 문자열을 리턴
let strOfComponentJoined = alphabetNSArray.componentsJoined(by: "#")
print(strOfComponentJoined)
/* NSArray의 배열 변환 끝 */

// ----------------------------------------------------------------------------------------- //

/* Array의 배열 변환 */
// joinWithSeparator()
let strOfJoined = alphabetArray.joined(separator: "#")
print(strOfJoined)

// map() --> 배열 요소를 순환하면서 클로저를 실행한 결과 값을 포함하고 있는 새로운 배열을 리턴
let resultOfMap = alphabetArray.map{ $0.lowercased() }
print(resultOfMap)
/* Array의 배열 변환 끝 */

// 3.11 ===================================================================================== //
print("3.11 =====================================================================================")

// 3.11 ContiguousArray, ArraySlice
// Array와 동일한 인터페이스를 가진 배열들이다. 특수한 경우 성능향상을 위해 사용된다.
// ContiguousArray --> Objective-C와 비호환, 모든 요소가 연속된 메모리에 저장, 클래스나 Objective-C 프로토콜을 저장하는 경우에 사용하면 성능항샹
// ArraySlice --> Objective-C와 비호환, 모든 요소가 연속된 메모리에 저장, 프로그램 내에서 일정시간 유지되는 데이터 저장 용도는 부적합하며 배열 특정 범위 추추하여 작업 처리용으로 많이 사용

// 3.12 ===================================================================================== //
print("3.12 =====================================================================================")

// 3.12 Array 배열의 메모리 공간과 최적화
// 배열은 초기화 당시 최초 저장 공간의 크기가 결정 --> 추가 요소에 의해 공간이 부족하면 Exponential Growth Strategy로 저장공간을 새로 할당(기존 저장공간의 2배를 할당)
// 따라서 성능에 영향을 최대한 적게 발생하도록 유도
// reserveCapacity() 메소드를 통해 임의 저장공간 할당 가능 --> 파라미터보다 같거나 크게 할당된다.
var list = ["A", "B", "C"]
print("total: \(list.capacity), current: \(list.count)") // 3 3

list += ["D"]
print("total: \(list.capacity), current: \(list.count)") // 6 4

list += ["E", "F", "G", "H", "I"]
print("total: \(list.capacity), current: \(list.count)") // 12 9

list[1..<6] = ["A"]
print("total: \(list.capacity), current: \(list.count)") // 12 5

var reservedList = [String]()
reservedList.reserveCapacity(100)
print("total: \(reservedList.capacity), current: \(reservedList.count)") // 105 0





































