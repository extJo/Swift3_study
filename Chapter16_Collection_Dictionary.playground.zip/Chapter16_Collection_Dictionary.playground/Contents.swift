//
//  main.swift
//  Chapter18_Collection_Dictionary
//
//  Created by JoYoungHo on 2017. 1. 15..
//  Copyright © 2017년 JoYoungHo. All rights reserved.
//

import Foundation


// [키:값, 키:값, ...]
// 선언과 동시에 초기화
let wordsNSDict: NSDictionary = ["A": "Apple", "B": "Banana", "C": "City"] // Foundation
print(wordsNSDict)


let wordsDict = ["A": "Apple", "B": "Banana", "C": "City"] // Swift
print(wordsDict)

// 수정 가능한 Dictionary
// 빈 Dictionray 를 선언하는 여러가지 방법
var emptyWordDict1: Dictionary<String, String> = [:] // 반드시 키와 값의 자료형 지정
var emptyWordDict2: [String:String] = [:]
var emptyWordDict3 = [String:String]()
let emptyNSMutableDict = NSMutableDictionary() // Foundation


// 4.1 ======================================================================================== //

// 4.1 딕셔너리에 포함된 요소의 수
/* NSDictionary의 요소의 수 */
let countOfWordsInNSDict = wordsNSDict.count

if countOfWordsInNSDict > 0
{
    print("\(countOfWordsInNSDict) elements(s)") // 3
}
else
{
    print("empty dictionary")
}


/* NSDictionary의 요소의 수 끝 */

// -------------------------------------------------------------------------------------------- //

/* Dictionary의 요소의 수 */
let countOfWordsInDict = wordsDict.count

if !wordsDict.isEmpty
{
    print("\(countOfWordsInDict) elements(s)")
}
else
{
    print("empty dictionary")
}
/* Dictionary의 요소의 수 끝 */


// 4.2 ======================================================================================== //

// 4.2 요소에 접근

/* NSDictionary의 요소 접근법 */
// object 메소드
let aValueOfNSDict = wordsNSDict.object(forKey: "A")
print(aValueOfNSDict) // Optional Value

let zValueOfNSDIct = wordsNSDict.object(forKey: "Z")
print(zValueOfNSDIct) // nil

// if 를 통해 nil 을 체크하는것이 안전
if let zValueOfNSDIct = wordsNSDict.object(forKey: "Z")
{
    print(zValueOfNSDIct) // nil
}

// 서브스크립 문법
if let aValueOFNSDict2 = wordsNSDict["A"]
{
    print(aValueOFNSDict2) // Apple
}
else
{
    print("Not Found")
}

if let zValueOFNSDict2 = wordsNSDict["Z"]
{
    print(zValueOFNSDict2)
}
else
{
    print("Not Found") // Not Found
}

// 모든 키, 값 추출하기
// allValutes, allKeys

let keysOfNSDict = wordsNSDict.allKeys
print(keysOfNSDict) // "A" "B" "C"

let valuesOfNSDict = wordsNSDict.allValues
print(valuesOfNSDict) // "Apple" "Banana" "City"
/* NSDictionary의 요소 접근법 끝 */

// -------------------------------------------------------------------------------------------- //

/* Dictionary의 요소 접근 법 */
// 서브스크립 문법을 사용하여 접근한다

// 모든 키, 값 추출하기
// NSDictionary와 다르게, LazyMapCollection을 리턴하기 때문에, 배열로 변경하려면, LazyMapCollection을 Array의 생성자로 전달해야 한다.
let keysOfDict = Array(wordsDict.keys)
print(keysOfDict) // "A" "B" "C"

let valuesOfDict = Array(wordsDict.values)
print(valuesOfNSDict) // "Apple" "Banana" "City"
/* Dictionary의 요소 접근 법 끝 */


// 4.3 ======================================================================================== //

// 4.3 키, 값 검색

/* NSDictionary의 키, 값 검색 방법 */
// 1. objectForKey()
// 2. allKeys 속성으로 배열 받아 배열의 contain() 사용
let key = "K"

if let _ = wordsNSDict.object(forKey: key)
{
    print("The key \"\(key)\" exists")
}
else
{
    print("The key \"\(key)\" not exists") // not exits
}

if wordsNSDict.allKeys.contains(where: { String(stringLiteral: $0 as! String) == key })
{
    print("The key \"\(key)\" exists")
}
else
{
    print("The key \"\(key)\" not exists") // not exits
}

// 객체와 연관된 키 검색하기
// allKeysForObject() --> 키가 있다면 배열로 리턴, 없다면 빈 배열 리턴
// 위의 메소드와 count속성을 활용하여 특정 객체와 연관된 키 존재 여부 확인 가능
let keys = wordsNSDict.allKeys(for: "Apple")
print("Key Count of Apple: \(keys.count)") // 1

// 상세한 검색 조건 구현
// keysOfEntriesPassingTest()
let resultOfNSDict = wordsNSDict.keysOfEntries(options: [], passingTest: {
    (key, obj, stop) -> Bool in
    if let value = obj as? String
    {
        return value.range(of: "a", options: .caseInsensitive) != nil
    }
    return false
})
for keyObj in resultOfNSDict
{
    if let key = keyObj as? NSString, let value = wordsNSDict[key]
    {
        print("\(key) - \(value)") // "Apple" "Banana"
    }
}
// 위의 방법은 NSDictionary 내 모든 요소에 대해 검색을 실시 하기 때문에, 원하는 결과가 나온뒤 멈추게 하는 것이 성능 향상에 도움이 될 것이다.
// --> stop 파라미터를 활용한다, 포인터로 전달해야 한다
let resultOfNSDict2 = wordsNSDict.keysOfEntries(options: [], passingTest: {
    (key, obj, stop) -> Bool in
    if let value = obj as? String
    {
        stop.pointee = true
        return value.range(of: "a", options: .caseInsensitive) != nil
    }
    return false
})
for keyObj in resultOfNSDict2
{
    if let key = keyObj as? NSString, let value = wordsNSDict[key]
    {
        print("\(key) - \(value)") // "Apple" "Banana"
    }
}
/* NSDictionary의 키, 값 검색 방법 끝 */


// -------------------------------------------------------------------------------------------- //


/* Dictionary의 키, 값 검색 방법 */
// contains()
if wordsDict.contains(where: { (key, value) -> Bool in return key == "A"})
{
    print("contains A key")
}
if wordsDict.contains(where: { $0.1 == "City" }) // 튜플 형태로 클로져에 전달됨
{
    print("contains City value")
}

// filter() --> 조건으로 검색후 일치하는 요소 튜플 배열로 리턴
let resultOfDict = wordsDict.filter{
    (key, value) -> Bool in
    return value.lowercased().contains("a")
}

for (key, value) in resultOfDict
{
    print("\(key) - \(value)")
}
/* Dictionary의 키, 값 검색 방법 끝 */


// 4.4 ======================================================================================== //

// 4.4 딕셔너리 비교

/* NSDictionary의 비교 */
// 저장된 요소의 순서는 상관없다
// isEuqalToDictionary()
let anotherWordsDict = ["B": "Banana", "C": "City", "A": "Apple"]
let countryCodesDict = ["KR": "South Korea", "US": "United States"]

if wordsNSDict.isEqual(to: anotherWordsDict)
{
    print("wordsNSDict == anotherWordsDict")
}
else
{
    print("wordsNSDict != anotherWordsDict")
}

if wordsNSDict.isEqual(to: countryCodesDict)
{
    print("wordsNSDict == countryCodesDict")
}
else
{
    print("wordsNSDict != countryCodesDict")
}
/* NSDictionary의 비교 끝 */


// -------------------------------------------------------------------------------------------- //

/* Dictionary의 비교 */
// 대소문 구분하여 비교
// == 연산자
if wordsDict == anotherWordsDict
{
    print("worsDict == anotherWordsDict")
}
else
{
    print("worsDict != anotherWordsDict")
}

if wordsDict == countryCodesDict
{
    print("worsDict == countryCodesDict")
}
else
{
    print("worsDict != countryCodesDict")
}

// elementsEqual() --> 비교 조건 상세하게
let upperWordsDict = ["A": "APPLE", "B": "BANANA", "C": "CITY"]


let equalsOfDict = wordsDict.elementsEqual(upperWordsDict, by: {
    (lhs, rhs) -> Bool in
    return lhs.0.lowercased() == rhs.0.lowercased()
        && lhs.1.lowercased() == rhs.1.lowercased()
})
print(equalsOfDict) // true
/* Dictionary의 비교 끝 */

// 4.5 ======================================================================================== //

// 4.5 새로운 요소 추가와 교체
/* NSMutableDictionary의 요소 추가 교체 방법 */
// setObject() --> 키가 존재하지 않을 경우 새로운 요소로 추가하고, 존재할 경우 값을 교체
let wordsNSMutableDict = NSMutableDictionary()

wordsNSMutableDict.setObject("Apple", forKey: "A" as NSCopying)
wordsNSMutableDict.setObject("Banana", forKey: "B" as NSCopying)
print(wordsNSMutableDict) // "B": "Banana" "A": "Apple" // 추가

wordsNSMutableDict.setObject("Blue", forKey: "B" as NSCopying)
print(wordsNSMutableDict) // "B": "Blue" "A": "Apple" // 교체

// 서브스크립트를 활용
wordsNSMutableDict.removeAllObjects()
wordsNSMutableDict["A"] = "Apple"
wordsNSMutableDict["B"] = "Banana"
print(wordsNSMutableDict) // "B": "Banana" "A": "Apple"

wordsNSMutableDict["B"] = "Blue"
print(wordsNSMutableDict) // "B": "Blue" "A": "Apple"
/* NSMutableDictionary의 요소 추가 교체 방법 끝 */

// -------------------------------------------------------------------------------------------- //

/* Dictionary의 요소 추가 및 교체 */
var wordsVarDict = [String:String]()
wordsVarDict["A"] = "Apple"
wordsVarDict["B"] = "Banana"
print(wordsVarDict) // "B": "Banana" "A": "Apple"

wordsVarDict["B"] = "Blue"
print(wordsVarDict) // "B": "Blue" "A": "Apple"

// updateValue() --> NSDictionary의 setObject()와 비슷한 기능을 하지만, 키가 이미 존재하면 현재 값을 리턴, 존재하지 않을 경우 nil 리턴 --> 추가 교체를 구분할 수 있다
if let oldValueOfVarDict = wordsVarDict.updateValue("Apple", forKey: "A")
{
    print("\(oldValueOfVarDict) => \(wordsVarDict["A"]!)")
}
else
{
    print("+ \(wordsVarDict["A"]!)") // + Apple
}

if let oldValueOfVarDict = wordsVarDict.updateValue("Apricot", forKey: "A")
{
    print("\(oldValueOfVarDict) => \(wordsVarDict["A"]!)") // Apple => Apricot
}
else
{
    print("+ \(wordsVarDict["A"]!)") // + Apple
}
/* Dictionary의 요소 추가 및 교체 끝 */


// 4.6 ======================================================================================== //

// 4.6 요소 삭제
// 가장 간단한 방법은 서브스크립 문법을 활용해 nil 을 넣어주는것
// 키가 존재하면 요소 삭제하고, 존재하지 않으면 무시

wordsVarDict = ["A": "Apple", "B": "Banana", "C": "City"]
wordsVarDict["C"] = nil
print(wordsVarDict) // "A": "Apple" "B": "Banana"


/* NSMutableDictionary의 요소 삭제 방법 */
// 1. 서브스크립트 방법
// 2. removeObjectForkey()
// 3. removeObjectsForKeys()
// 4. removeAllObjects()
let wordsNSMutableDict2 = NSMutableDictionary(dictionary: ["A": "Apple", "B": "Banana", "C": "City", "D": "Drama", "E": "Earth", "F": "Fuel"])

wordsNSMutableDict2.removeObject(forKey: "D")
print(wordsNSMutableDict2) // "A": "Apple", "B": "Banana", "C": "City", "E": "Earth", "F": "Fuel"

wordsNSMutableDict2.removeObjects(forKeys: ["A", "F"])
print(wordsNSMutableDict2) // "C: "City" "B": "Banana" "E": "Earth"

wordsNSMutableDict2.removeAllObjects()
print(wordsNSMutableDict2) // [:]
/* NSMutableDictionary의 요소 삭제 방법 끝 */

// -------------------------------------------------------------------------------------------- //

/* Dictionary의 요소 삭제 방법 */
var wordsVarDict2 = ["A": "Apple", "B": "Banana", "C": "City", "D": "Drama", "E": "Earth", "F": "Fuel"]

if let removedValue = wordsVarDict2.removeValue(forKey: "D")
{
    print("\(removedValue) removed!") // Drama removed!
}
print(wordsVarDict2) // "A": "Apple", "B": "Banana", "C": "City", "E": "Earth", "F": "Fuel"

wordsVarDict2.removeAll()
print(wordsVarDict2) // [:]

wordsVarDict.removeAll(keepingCapacity: true) // 저장공간 살려놓음
/* Dictionary의 요소 삭제 방법 끝 */










