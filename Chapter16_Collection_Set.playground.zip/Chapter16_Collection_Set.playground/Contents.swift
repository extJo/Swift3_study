//
//  main.swift
//  Chapter18_Collection_Set
//
//  Created by JoYoungHo on 2017. 1. 15..
//  Copyright © 2017년 JoYoungHo. All rights reserved.
//

import Foundation

// 배열과 동일한 리터럴을 사용하여 정의
// [.....]

let fruitsArray = ["Apple", "Banana", "Melon"]

let fruitsFromArrayNSSet = NSSet(array: fruitsArray)
let fruitsFromSetNSSet = NSSet(set: fruitsFromArrayNSSet)
let fruitsNSSet = NSSet(objects: "Apple", "Banana", "Melon")
let emptyNSSet = NSSet()

// Swift 에서는 반드시 자료형을 지정해야 한다.
// [String]과 같이 선언하면 배열을 표현하는 것이다.
let fruitsSet: Set<String> = ["Apple", "Banana", "Melon"]
let numbersSet: Set = [1, 2, 3]
let emptySet = Set<String>()


// 5.1 ===================================================================== //

// 5.1 요소의 수
/* NSSet 의 요소의 수 */
// anyObject() --> 비었는지 확인가능
var countOfFruitsNSSet = fruitsNSSet.count
if let _ = fruitsNSSet.anyObject() // 비었는지 확인
{
    print("\(countOfFruitsNSSet) elements(s)")
}
else
{
    print("Empty NSSet")
}
/* NSSet 의 요소의 수 끝 */

// ------------------------------------------------------------------------- //

/* Set 의 요소이 수 */
var countOfFruitsSet = fruitsSet.count
if !fruitsSet.isEmpty
{
    print("\(countOfFruitsSet) elements(s)")
}
else
{
    print("Empty Set")
}
/* Set 의 요소이 수 끝 */

// 5.2 ===================================================================== //

// 5.2 요소 검색
/* NSSet 의 검색 방법 */
// contains()
if fruitsNSSet.contains("Apple")
{
    print("fruitsNSSet contains Apple")
}

// NSPredicate 활용하여 검색 조건 상세화
// filterd()
let productNSSet = NSSet(objects: "iPhone", "iPad", "Mac Pro", "iPad Pro", "Macbook Pro")

let prefixPredicateOfNSSet = NSPredicate(format: "SELF BEGINSWITH %@", "i")
let filteredNSSet = productNSSet.filtered(using: prefixPredicateOfNSSet)
print(filteredNSSet) // "iPhone" "iPad" "iPad Pro"

let productNSMutableSet = NSMutableSet(set: productNSSet)
let suffixPredicateOfNSMutSet = NSPredicate(format: "SELF ENDSWITH %@", "o")
productNSMutableSet.filter(using: suffixPredicateOfNSMutSet)
print(productNSMutableSet) // "Mac Pro" "iPad Pro" "Macbook Pro"
/* NSSet 의 검색 방법 끝 */

// ------------------------------------------------------------------------- //

/* Set 의 검색 방법 */
// contains()
if fruitsSet.contains("Apple")
{
    print("fruitsSet contains Apple")
}

// filter()
let productSet: Set = ["iPhone", "iPad", "Mac Pro", "iPad Pro", "Macbook Pro"]
let filteredSet = productSet.filter {
    (element) -> Bool in
    return element.hasPrefix("i")
}
print(filteredSet)
/* Set 의 검색 방법 끝 */

// 5.3 ===================================================================== //

// 5.3 요소 추가

/* NSMutableSet의 요소 추가 방법 */
// add()
// addObject()
let NSMutSet = NSMutableSet()
NSMutSet.add("Apple")
NSMutSet.add("Apple")
print(NSMutSet) // {"Apple"}

var alphabetArray = ["A", "B"]
NSMutSet.addObjects(from: alphabetArray)
print(NSMutSet) // {"Apple", "A", "B"}

alphabetArray = ["A", "B", "C"]
NSMutSet.addObjects(from: alphabetArray)
print(NSMutSet) // {"Apple", "A", "B", "C"
/* NSMutableSet의 요소 추가 방법 끝 */

// ------------------------------------------------------------------------- //


/* Set의 요소 추가 방법 */
// insert()
var set: Set<String> = []
set.insert("Apple")
print(set) // {"Apple"}

var resultOfSetInsert = set.insert("Orange")
print(resultOfSetInsert) // {true, "Orange"} // 없는 것으로 추가됨
print(set) // {"Apple", "Orange}

resultOfSetInsert = set.insert("Orange")
print(resultOfSetInsert) // {false, "Orange"} // 있는 것으로 추가되지 않음
print(set) // {"Apple", "Orange}
/* Set의 요소 추가 방법 끝 */

// 5.4 ===================================================================== //

// 5.4 요소 삭제

/* NSMutableSet의 요소 삭제 */
// remove()
// removeAllObjects()
let NSMutSet2 = NSMutableSet(array: ["Apple", "Orange", "Melon"])
NSMutSet2.remove("Apple")
print(NSMutSet2) // {"Orange", "Melon"}

NSMutSet2.removeAllObjects()
print(NSMutSet2) // {}
/* NSMutableSet의 요소 삭제 끝 */

// ------------------------------------------------------------------------- //

/* Set의 요소 삭제 */
// remove()
// removeAll()
set = ["Apple", "Orange", "Melon"]
if let removedFromSet = set.remove("Apple")
{
    print("\(removedFromSet) has been removed!") // Apple has been removed!
}
print(set) // {"Orange", "Melon"}

set.removeAll(keepingCapacity: true) // 저장 공간은 살린다
print(set) // {}
/* Set의 요소 삭제 끝 */

// 5.5 ===================================================================== //

// 5.5 비교, 부분집합

/* NSSet의 비교 */
// isEqual()
let favoriteFruitsNSSet = NSSet(objects: "Apple", "Orange", "Melon")
let tropicalFruitsNSSet = NSSet(objects: "Banana", "Papaya", "Kiwi", "Pineapple")

if favoriteFruitsNSSet.isEqual(to: tropicalFruitsNSSet as Set<NSObject>)
{
    print("favoriteFruitsNSSet == tropicalFruitsNSSet")
}
else
{
    print("favoriteFruitsNSSet != tropicalFruitsNSSet")
}

// isSubset() --> 파라미터로 전달된 집합의 부분집합일 때 YES or true
let tropicalFruitsSet = Set(["Banana", "Papaya", "Kiwi", "Pineapple"])
let yellowFruitsNSSet = NSSet(array: ["Banana"])

if yellowFruitsNSSet.isSubset(of: tropicalFruitsSet)
{
    print("yellowFruitsNSSet ⊂ tropicalFruitsSet")
}
else
{
    print("yellowFruitsNSSet ⊄ tropicalFruitsSet")
}
/* NSSet의 비교 끝 */

// ------------------------------------------------------------------------- //

/* Set의 비교 */
// == 연산자
// elementEqual()
let favoriteFruitsSet = Set(["Apple", "Orange", "Melon"])

if favoriteFruitsSet == tropicalFruitsSet
{
    print("favoriteFruitsSet == tropicalFruitsSet")
}
else
{
    print("favoriteFruitsSet != tropicalFruitsSet")
}

if favoriteFruitsSet.elementsEqual(tropicalFruitsSet)
{
    print("favoriteFruitsSet == tropicalFruitsSet")
}
else
{
    print("favoriteFruitsSet != tropicalFruitsSet")
}

// 부분집합, 진부분집합, 상위집합, 진상위집합
// isSubset()
// isStrictSubset()
// isSuperset()
// isStrickSuperset()
let yellowFruitsSet = Set(["Banana"])


if yellowFruitsSet.isSubset(of: tropicalFruitsSet) // 부분집합
{
    print("yellowFruitsSet ⊂ tropicalFruits") // yellowFruits ⊂ tropicalFruits
}
else
{
    print("yellowFruitsSet ⊄ tropicalFruits")
}


if yellowFruitsSet.isStrictSubset(of: tropicalFruitsSet) // 진부분집합
{
    print("yellowFruitsSet ⊂ tropicalFruits") // yellowFruitsSet ⊂ tropicalFruits
}
else
{
    print("yellowFruitsSet ⊄ tropicalFruits")
}


if tropicalFruitsSet.isSuperset(of: yellowFruitsSet) // 상위집합
{
    print("tropicalFruits ⊃ yellowFruitsSet") // tropicalFruits ⊃ yellowFruits
}
else
{
    print("tropicalFruits ⊅ yellowFruitsSet")
}


if tropicalFruitsSet.isStrictSuperset(of: yellowFruitsSet) // 진상위집합
{
    print("tropicalFruits ⊃ yellowFruitsSet") // tropicalFruits ⊃ yellowFruits
}
else
{
    print("tropicalFruits ⊅ yellowFruitsSet")
}
/* Set의 비교 끝 */

// 5.6 ===================================================================== //

// 5.6 집합 연산 - 교집합
/* NSSet, NSMutableSet 의 교집합 */
// intersects()
let favoriteFruitsNSSet2 = NSSet(array: ["Apple", "Orange", "Melon", "Kiwi"])
let tropicalFruitsNSMutSet = NSMutableSet(array: ["Banana", "Papaya", "Kiwi", "Pineapple"])


if favoriteFruitsNSSet2.intersects(tropicalFruitsNSMutSet as Set<NSObject>)
{
    print("favoriteFruitsNSSet2 ∩ tropicalFruitsNSMutSet")
    
    tropicalFruitsNSMutSet.intersect(favoriteFruitsNSSet2 as Set<NSObject>)
    print(tropicalFruitsNSMutSet)
}
else
{
    print("favoriteFruitsNSSet2 ∩ tropicalFruitsNSMutSet = ∅")
}
/* NSSet, NSMutableSet 의 교집합 끝 */

// ------------------------------------------------------------------------- //

/* Set의 교집합 */
// isDisjoint() --> 두 집합이 서로소 인지 확인
// intersection() --> 교집합을 새로운 셋으로 리턴
// intersectInPlace --> formIntersection() --> 교집합을 제외한 나머지 요소 삭제
let favoriteFruitsSet2 = Set(["Apple", "Orange", "Melon", "Kiwi"])
var tropicalFruitsSet2 = Set(["Banana", "Papaya", "Kiwi", "Pineapple"])

if favoriteFruitsSet2.isDisjoint(with: tropicalFruitsSet2) // 확인
{
    print("favoriteFruitsSet2 ∩ tropicalFruitsSet2")

}
else
{
    print("favoriteFruitsSet2 ∩ tropicalFruitsSet2 = ∅")
}

let commonSet = favoriteFruitsSet2.intersection(tropicalFruitsSet2) // 만들기
print(commonSet) // {"Kiwi"}

tropicalFruitsSet2.formIntersection(favoriteFruitsSet2) // 수정하기
print(tropicalFruitsSet2) // {"Kiwi"}
/* Set의 교집합 끝 */

// 5.7 ===================================================================== //

// 5.7 집합 연산 - 합집합

/* NSMutableSet 의 합집합 */
// union()
let favoriteFruitsSet3 = Set(["Apple", "Orange", "Melon", "Kiwi"])
var tropicalFruitsSet3 = Set(["Banana", "Papaya", "Kiwi", "Pineapple"])

let unionNSMutSet = NSMutableSet(set: favoriteFruitsSet3)

unionNSMutSet.union(tropicalFruitsSet3)
print(unionNSMutSet) // {"Orange", "Banana", "Papaya", "Pineapple", "Kiwi", "Apple", "Melon"}

/* NSMutableSet 의 합집합 끝 */

// ------------------------------------------------------------------------- //

/* Set 의 합집합 */
// union --> 새 집합 리턴
// formUnion --> 현재 집합에 요소를 더 추가 (집합을 수정)
var unionSet = favoriteFruitsSet3.union(tropicalFruitsSet3)
print(unionSet) // {"Orange", "Banana", "Papaya", "Pineapple", "Kiwi", "Apple", "Melon"}

unionSet = Set(favoriteFruitsSet3)

unionSet.formUnion(tropicalFruitsSet3)
print(unionSet) // {"Orange", "Banana", "Papaya", "Pineapple", "Kiwi", "Apple", "Melon"}
/* Set 의 합집합 끝 */

// 5.8 ===================================================================== //

// 5.8 집합 연산 - 차집합
/* NSMutableSet의 차집합 */
let favoriteFruitsNSMutSet = NSMutableSet(array: ["Apple", "Orange", "Melon", "Kiwi"])
let tropicalFruitsSet4 = Set(["Banana", "Papaya", "Kiwi", "Pineapple"])

favoriteFruitsNSMutSet.minus(tropicalFruitsSet4)
print(favoriteFruitsNSMutSet) // {"Apple", "Orange", "Melon"}
/* NSMutableSet의 차집합 끝 */

// ------------------------------------------------------------------------- //

/* Set의 차집합 */
// subtracting() --> 새로운 셋 리턴
// subtract() --> 기존 셋에서 빼기
var favoriteFruitsSet5 = Set(["Apple", "Orange", "Melon", "Kiwi"])
let tropicalFruitsSet5 = Set(["Banana", "Papaya", "Kiwi", "Pineapple"])

let uncommonSet = favoriteFruitsSet5.subtracting(tropicalFruitsSet5)
print(uncommonSet) // {"Apple", "Orange", "Melon"}

favoriteFruitsSet5.subtract(tropicalFruitsSet5)
print(favoriteFruitsSet5) // {"Apple", "Orange", "Melon"}
/* Set의 차집합 끝 */

// 5.9 ===================================================================== //

// 5.9 집합 연산 - 여집합

/* Set의 여집합 */
// exclusiveOr() --> symmetricDifference() --> 새로운 여집합을 리턴
// exclusiveOrInPlace() --> formSysmmetricDifference() --> 여집합으로 수정
var favoriteFruitsSet6 = Set(["Apple", "Orange", "Melon", "Kiwi"])
let tropicalFruitsSet6 = Set(["Banana", "Papaya", "Kiwi", "Pineapple"])

let exclusiveSet = favoriteFruitsSet6.symmetricDifference(tropicalFruitsSet6) // 새로운 여집합 리턴
print(exclusiveSet) // {"Apple", "Orange", "Melon", "Banana", "Pineapple", "Papaya"}

favoriteFruitsSet6.formSymmetricDifference(tropicalFruitsSet6) // 기존으 집합을 수정하여 여집합 만들기
print(favoriteFruitsSet6) // {"Apple", "Orange", "Melon", "Banana", "Pineapple", "Papaya"}
/* Set의 여집합 끝 */

// 5.10 ===================================================================== //

// 5.10 NSCountedSet
// 중복을 허용하는 셋, NSMutableSet의 자식 클래스
// 주의. 지울때 중복되는 숫자만큼 다 지워야 정확하게 지워진다

// 세 개의 Apple
let NSCountSet = NSCountedSet()
NSCountSet.add("Apple")
NSCountSet.add("Apple")
NSCountSet.add("Apple")
print(set) // {"Apple"}

var countOfApple = NSCountSet.count(for: "Apple")
print(countOfApple) // 3

NSCountSet.remove("Apple")
print(NSCountSet) // {"Apple"} // 2개 남음

countOfApple = NSCountSet.count(for: "Apple")
print(countOfApple) // 2

NSCountSet.remove("Apple")
NSCountSet.remove("Apple")
print(NSCountSet) // {} // 이제서야 비워짐

countOfApple = NSCountSet.count(for: "Apple")
print(countOfApple) // 0
